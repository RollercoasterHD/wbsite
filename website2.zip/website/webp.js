var menuopen = false;
if (document.getElementById("javascriptreference") == null) {
	menuopen= true;
}
var animation = false;
var menubutton = document.getElementById("menubtn");
var menusite = document.getElementById("sidemenu");
var cerntext = document.getElementById("cerntext");
var cernhomepic = document.getElementById("cernhomepic")
function changeMenu() {
	if (menuopen == false && animation == false) {
		menuopen = true;
		animation = true;
		menubutton.className = "menubuttonleftright";
		menusite.className = "siteleftright";
		cerntext.className = "cerntextleftright";
		cernhomepic.className = "cernhomepicleftright";
		setTimeout(function(){menubutton.className = "menubuttonright";cerntext.className = "cerntextside";cernhomepic.className = "cernhomepicside";menusite.className = "siteopen";animation = false;}, 475);
	}
	else if (animation == false){
		menuopen = false;
		animation = true;
		menubutton.className = "menubuttonrightleft";
		menusite.className = "siterightleft";
		cerntext.className = "cerntextrightleft";
		cernhomepic.className = "cernhomepicrightleft";
		setTimeout(function(){menubutton.className = "menubutton";cerntext.className = "cerntext";cernhomepic.className = "cernhomepic";menusite.className = "site";animation = false;}, 500);
	}
	console.log("Now");
}